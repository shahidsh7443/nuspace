<?php
global $archi_option;
/**
 * Redux Theme functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package archi
 */

if ( ! class_exists( 'ReduxFramewrk' ) ) {
    require_once( get_template_directory() . '/framework/sample-config.php' );
    function archi_removeDemoModeLink() { // Be sure to rename this function to something more unique
        if ( class_exists('ReduxFrameworkPlugin') ) {
            remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2 );
        }
        if ( class_exists('ReduxFrameworkPlugin') ) {
            remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );    
        }
    }
    add_action('init', 'archi_removeDemoModeLink');
}

//Theme Set up:
function archi_theme_setup() {

    /** Set Content width **/
    if ( ! isset( $content_width ) ) {
        $content_width = 900;
    }

   /*
     * Make theme available for translation.
     * Translations can be filed in the /languages/ directory.
     * If you're building a theme based on cubic, use a find and replace
     * to change 'cubic' to the name of your theme in all the template files
     */
	load_theme_textdomain( 'archi', get_template_directory() . '/languages' );

    /*
     * This theme uses a custom image size for featured images, displayed on
     * "standard" posts and pages.
     */
	add_theme_support( 'custom-header' ); 
	add_theme_support( 'custom-background' );
	add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );

    // Add Image Size Function customize image    
    add_image_size( 'thumb-blog', 540, 300, true ); // 220 pixels wide by 180 pixels tall, soft proportional crop mode
    add_image_size( 'thumb-portfolio', 700, 466, true ); // 220 pixels wide by 180 pixels tall, hard crop mode
    add_image_size( 'thumb-service', 700, 358, true ); // Hard crop left top
    
    // Adds RSS feed links to <head> for posts and comments.
    add_theme_support( 'automatic-feed-links' );
    // Switches default core markup for search form, comment form, and comments
    // to output valid HTML5.
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );
    //Post formats
    add_theme_support( 'post-formats', array(
        'audio',  'gallery', 'image', 'video',
    ) );
	//Tags
	add_theme_support( 'title-tag' );
    // This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary'   => __('Primary Menu', 'archi'),
        'onepage'   => __('One Page Menu', 'archi'),
        'landing'   => __('Landing Page Menu', 'archi'),
		'service-menu'   => __('Service Page Menu', 'archi'),
	) );
}
add_action( 'after_setup_theme', 'archi_theme_setup' );

function archi_load_custom_wp_admin_style() {
        wp_register_style( 'custom_wp_admin_css', get_template_directory_uri() . '/framework/admin-style.css', false, '1.0.0' );
        wp_enqueue_style( 'custom_wp_admin_css' );
}
add_action( 'admin_enqueue_scripts', 'archi_load_custom_wp_admin_style' );

function archi_fonts_url() {
    $fonts_url = '';
 
    /* Translators: If there are characters in your language that are not
    * supported by Lora, translate this to 'off'. Do not translate
    * into your own language.
    */
    $dosis = _x( 'on', 'Dosis font: on or off', 'archi' );
 
    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'archi' );

    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $allura = _x( 'on', 'Allura font: on or off', 'archi' );  

    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $raleway = _x( 'on', 'Raleway font: on or off', 'archi' );   
 
    if ( 'off' !== $dosis || 'off' !== $open_sans || 'off' !== $allura ) {
        $font_families = array();
 
        if ( 'off' !== $dosis ) {
            $font_families[] = 'Dosis:400,200,300,500,600,700,800,900';
        }
 
        if ( 'off' !== $open_sans ) {
            $font_families[] = 'Open Sans:300,500,600,700,900,400';
        }

        if ( 'off' !== $raleway ) {
            $font_families[] = 'Raleway:400,200,200italic,300,300italic,400italic,500italic,500,600,600italic,700,700italic';
        }   

        if ( 'off' !== $allura ) {
            $font_families[] = 'Allura';
        }        
 
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    }
 
    return esc_url_raw( $fonts_url );
}

function archi_theme_scripts_styles() {
	global $archi_option;
	$protocol = is_ssl() ? 'https' : 'http';
    $gmap_api = $archi_option['gmap_api'];
    
    // Add custom fonts, used in the main stylesheet.
    wp_enqueue_style( 'archi-fonts', archi_fonts_url(), array(), null );
	
    /** All frontend css files **/ 
    wp_enqueue_style( 'archi-bootstrap', get_template_directory_uri().'/css/bootstrap.css');

    if($archi_option['preload-switch']!=false){
        if(isset($archi_option['preloader_mode']) and $archi_option['preloader_mode']=="preloader_progress" ){
            wp_enqueue_style( 'archi-jpreloader', get_template_directory_uri().'/css/jpreloader.css');
        }else{
            wp_enqueue_style( 'archi-jpreloader', get_template_directory_uri().'/css/royal-preloader.css');
        }
    }

    if($archi_option['animate-switch']!=false){
    	wp_enqueue_style( 'archi-animate', get_template_directory_uri().'/css/animate.css');
    }
	wp_enqueue_style( 'archi-plugin', get_template_directory_uri().'/css/plugin.css');    

    /** load fonts **/
    wp_enqueue_style( 'archi-css-font-awesome', get_template_directory_uri().'/fonts/font-awesome/css/font-awesome.css');    
    wp_enqueue_style( 'archi-et-line-font_font', get_template_directory_uri().'/fonts/et-line-font/style.css');	

    wp_enqueue_style( 'archi-YTPlayer', get_template_directory_uri().'/css/jquery.mb.YTPlayer.min.css');

    /** Theme main style **/
	wp_enqueue_style( 'archi-style', get_stylesheet_uri(), array(), '25-10-2016' );
    
    if(isset($archi_option['header_layout']) and $archi_option['header_layout']=="hleft_side" ){
        wp_enqueue_style( 'archi-header-sidenav', get_template_directory_uri().'/css/header-sidenav.css');
    }elseif (isset($archi_option['header_layout']) and $archi_option['header_layout']=="hleft_side_light") {
        wp_enqueue_style( 'archi-header-sidenav-light', get_template_directory_uri().'/css/header-sidenav-light.css');
    }else{}
    

    if (class_exists('Woocommerce')) {
        wp_enqueue_style( 'archi-woocommerce', get_template_directory_uri().'/css/woocommerce.css');  
    }
    
    if($archi_option['version_type']=='light'){
        wp_enqueue_style( 'archi-style-light', get_template_directory_uri().'/css/light.css');        
    }    

    wp_enqueue_style( 'archi-style-rtl', get_template_directory_uri().'/rtl.css'); 

    /** Js for comment on single post **/    
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
    	wp_enqueue_script( 'comment-reply' );
	}   

    /** All frontend js files **/    
    if($archi_option['preload-switch']==true){
        if(isset($archi_option['preloader_mode']) and $archi_option['preloader_mode']=="preloader_progress" ){
            wp_enqueue_script("archi-jpreLoader", get_template_directory_uri()."/js/jpreLoader.js",array(),false,true);
        }else{
            wp_enqueue_script("archi-jpreLoader", get_template_directory_uri()."/js/royal_preloader.min.js",array(),false,false);
        }
    }

	wp_enqueue_script( "archi-maps-js", "$protocol://maps.googleapis.com/maps/api/js?key=$gmap_api",array('jquery'),false,false);
	wp_enqueue_script("archi-bootstrap-js", get_template_directory_uri()."/js/bootstrap.min.js",array(),false,true);
    wp_enqueue_script("archi-isotope", get_template_directory_uri()."/js/jquery.isotope.min.js",array(),false,true);	
    wp_enqueue_script("archi-total", get_template_directory_uri()."/js/total1.js",array(),false,true);
    
	if(!is_page_template('page-templates/template-coming-soon-page.php') || !is_page_template('page-templates/template-coming-soon-video.php')){ 
        wp_enqueue_script("archi-classie", get_template_directory_uri()."/js/classie.js",array(),false,true);
	}

    if($archi_option['animate-switch']==true){
        wp_enqueue_script("archi-wow-js", get_template_directory_uri()."/js/wow.min.js",array(),false,true);
    }
	wp_enqueue_script("archi-magnific-popup", get_template_directory_uri()."/js/jquery.magnific-popup.min.js",array(),false,true);
	wp_enqueue_script("archi-enquire", get_template_directory_uri()."/js/enquire.min.js",array(),false,true);
    wp_enqueue_script("archi-PageScroll2id", get_template_directory_uri()."/js/jquery.malihu.PageScroll2id.js",array(),false,false);
    wp_enqueue_script("archi-YTPlayer", get_template_directory_uri()."/js/jquery.mb.YTPlayer.min.js",array(),false,true);	
    wp_enqueue_script("archi-typed", get_template_directory_uri()."/js/typed.js",array(),false,true);
    wp_enqueue_script("archi-let-it-snow", get_template_directory_uri()."/js/let-it-snow.min.js",array(),false,true);
    wp_enqueue_script("archi-custom", get_template_directory_uri()."/js/designesia.js",array(),false,true);
}
add_action( 'wp_enqueue_scripts', 'archi_theme_scripts_styles');

if(!function_exists('archi_custom_frontend_scripts')){
    function archi_custom_frontend_scripts(){
        global $archi_option; 
    ?>
        <script type="text/javascript">
            window.jQuery = window.$ = jQuery;  
            (function($) { "use strict";
                <?php if(isset($archi_option['header_layout']) and $archi_option['header_layout']!="htop_page" ){ ?>
                    /* Page Scroll to id fn call */ 
                    jQuery(".mainmenu li a, a[href^='#']:not(.woocommerce-tabs ul li a, .vc_tta-panel-heading a, .vc_tta-tabs-list li a), a.scroll-to").mPageScroll2id({
                        highlightSelector:".mainmenu li a",
                        offset: 0,
                        scrollSpeed:750,
                        scrollEasing: "easeInOutCubic"
                    });
                <?php }else{ ?>
                    /* Page Scroll to id fn call */ 
                    jQuery("#mainmenu li a, a[href^='#']:not(.woocommerce-tabs ul li a, .vc_tta-panel-heading a, .vc_tta-tabs-list li a), a.scroll-to").mPageScroll2id({
                        highlightSelector:"#mainmenu li a",
                        offset: 68,
                        scrollSpeed:750,
                        scrollEasing: "easeInOutCubic"
                    }); 
                <?php } ?> 

                /* Enable/Disable Animate Scroll on Desktop and Mobile */
                <?php if($archi_option['animate-switch']!=false){ ?>
                    <?php                     
                        if($archi_option['animate-mobile-switch']==false){ 
                        $mobile_size = (!empty($archi_option['animation_mobile_screen_size'])) ? esc_attr($archi_option['animation_mobile_screen_size']) : 768;
                    ?>
                        jQuery(document).ready(function() {'use strict'; 
                            var width = $(window).width(); 
                            if(width >= <?php echo $mobile_size; ?>){                                 
                                new WOW().init(); 
                            } 
                        });
                    <?php }else{ ?>
                        jQuery(document).ready(function() {'use strict';                                                     
                            new WOW().init();                         
                        });
                    <?php } ?>
                <?php } ?>

                <?php if(isset($archi_option['preloader_mode']) and $archi_option['preloader_mode']=="preloader_logo" and $archi_option['preload-switch']==true ){ ?>
                    //Preloader Logo
                    Royal_Preloader.config({
                        mode           : 'logo',
                        logo           : '<?php echo esc_js($archi_option['logo_preload']['url']); ?>',
                        logo_size      : [<?php echo esc_js($archi_option['prelogo_width']); ?>, <?php echo esc_js($archi_option['prelogo_height']); ?>],
                        showProgress   : true,
                        showPercentage : true,
                        text_colour: '<?php echo esc_js($archi_option['preload-text-color']); ?>',
                        background:  '<?php echo esc_js($archi_option['preload-background-color']); ?>'
                    });
                <?php } ?>

            })(jQuery);
        </script>
    <?php        
    }
}
add_action('wp_footer', 'archi_custom_frontend_scripts');

// Widget Sidebar
function archi_widgets_init() {
	register_sidebar( array(
        'name'          => __( 'Primary Sidebar', 'archi' ),
        'id'            => 'sidebar-1',        
		'description'   => __( 'Appears in the sidebar section of the site.', 'archi' ),        
		'before_widget' => '<div id="%1$s" class="widget %2$s">',        
		'after_widget'  => '</div>',        
		'before_title'  => '<h4>',        
		'after_title'   => '</h4><div class="small-border"></div>'
    ) );
	register_sidebar( array(
        'name'          => __( 'Shop Sidebar', 'archi' ),
        'id'            => 'shop-sidebar',        
        'description'   => __( 'Appears in the sidebar section of the site.', 'archi' ),        
        'before_widget' => '<div id="%1$s" class="widget %2$s">',        
        'after_widget'  => '</div>',        
        'before_title'  => '<h4>',        
        'after_title'   => '</h4><div class="small-border"></div>'
    ) );
    register_sidebar( array(
		'name'          => __( 'Footer One Widget Area', 'archi' ),
		'id'            => 'footer-area-1',
		'description'   => __( 'Footer Widget that appears on the Footer.', 'archi' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Two Widget Area', 'archi' ),
		'id'            => 'footer-area-2',
		'description'   => __( 'Footer Widget that appears on the Footer.', 'archi' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Three Widget Area', 'archi' ),
		'id'            => 'footer-area-3',
		'description'   => __( 'Footer Widget that appears on the Footer.', 'archi' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Fourth Widget Area', 'archi' ),
		'id'            => 'footer-area-4',
		'description'   => __( 'Footer Widget that appears on the Footer.', 'archi' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );    
}
add_action( 'widgets_init', 'archi_widgets_init' );


/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/framework/template-tags.php';

/**
 * Additional features to allow styling of the templates.
 */
require get_template_directory() . '/framework/template-functions.php';

/** Woocommerce Customize **/
require get_template_directory() . '/framework/woocommerce-customize.php';

/** Custom Visual Composer template vc_templates **/
require get_template_directory() . '/framework/theme-custom-visual-template.php';

/** customize theme option for color **/
require get_template_directory() . '/framework/color.php';

/** Install Plugins Required **/
require get_template_directory() . '/framework/plugin-requires.php';

/*Code Visual Composer.*/
require get_template_directory() . '/vc_shortcode.php';

/**
 * Customizer shortcode.
 */
require get_template_directory() . '/shortcodes.php';

/**
 * Implement the Custom Meta Boxs.
 */
require get_template_directory() . '/framework/meta-boxes.php';

/**
 * Customizer menu item.
 */
require get_template_directory() . '/framework/wp_bootstrap_navwalker.php';

/**
 * Customizer images.
 */
require get_template_directory() . '/framework/BFI_Thumb.php';

?>